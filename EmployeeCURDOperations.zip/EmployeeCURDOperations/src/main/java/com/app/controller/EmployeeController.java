package com.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.modal.Employee;
import com.app.repo.EmployeeRepo;

@RestController
@RequestMapping("/emp")
public class EmployeeController {

	@Autowired
	EmployeeRepo repo;

	@GetMapping("/all")
	public List<Employee> getAllEmp() {
		return repo.findAll();
	}

	@PostMapping("/save")
	public Employee saveEmp(@RequestParam String firstName, @RequestParam String lastName,
			@RequestParam String mobileNumber, @RequestParam String address, @RequestParam String department) {

		Employee emp = new Employee();
		emp.setFirstName(firstName);
		emp.setLastName(lastName);
		emp.setMobileNumber(mobileNumber);
		emp.setAddress(address);
		emp.setDepartment(department);

		return repo.save(emp);
	}

	@PatchMapping("/update/{userId}")
	public Employee updateEmp(@PathVariable Integer userId, @RequestParam String firstName) {
		
		Optional<Employee> emp = repo.findById(userId);
		
		if(emp.isPresent()) {
			Employee e = emp.get();
			e.setFirstName(firstName);
			return repo.save(e);
		}else {
			return new Employee();
		}
	}
	
	@DeleteMapping("/delete/{userId}")
	public String deleteEmp(@PathVariable Integer userId) {		
		repo.deleteById(userId);
		return "Employee Deleted Successfully";
	}

}
